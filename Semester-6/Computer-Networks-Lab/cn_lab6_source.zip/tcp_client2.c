#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define BUFFERSIZE 1024
#define SERVERADDR "127.0.0.1"
#define SERVERPORT 5000
#define N 10  // Number of packets to send
#define ROLL_NUMBER "SC22B146"

int main()
{
    int sock, bytes_sent, conn_status;
    struct sockaddr_in s_server;
    char send_buf[BUFFERSIZE];
    char messages[N][100];

    // Create socket
    sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (sock < 0)
    {
        printf("Socket creation failed.\n");
        return 1;
    }
    printf("Socket creation successful with descriptor %d.\n", sock);

    s_server.sin_family = AF_INET;
    s_server.sin_port = htons(SERVERPORT);
    inet_aton(SERVERADDR, &s_server.sin_addr);

    // Connect to server
    conn_status = connect(sock, (struct sockaddr *)&s_server, sizeof(s_server));
    if (conn_status == -1)
    {
        printf("Connection to server failed.\n");
        close(sock);
        return 1;
    }
    printf("Connected to server.\n");

    // Prompts for messages to send
    for (int i = 0; i < N; i++) {
        printf("Enter message %d: ", i + 1);
        fgets(messages[i], sizeof(messages[i]) - 10, stdin); 
        messages[i][strcspn(messages[i], "\n")] = 0;
    }

    // Send packets
    for (int i = 0; i < N; i++) {
        snprintf(send_buf, BUFFERSIZE, "%02d:%s:%s\n", i, ROLL_NUMBER, messages[i]);  // Header

        bytes_sent = send(sock, send_buf, strlen(send_buf), 0);
        if (bytes_sent < 0) {
            printf("Error sending data\n");
            return 1;
        }
        printf("Sent packet %d: %s (%d bytes)\n", i, send_buf, bytes_sent);
    }

    close(sock);
    return 0;
}
