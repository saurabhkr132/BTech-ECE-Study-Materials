#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/select.h>

#define PORT 5000
#define GSU_PORT 6000
#define LOG_FILE "sensor_log.txt"
#define TRANSMIT_INTERVAL 120  // 2 minutes
#define PACKET_LOSS_RATE 0.1   // 10% packet loss

// Packet structure (same as Phase 2)
struct packet {
    unsigned int gen_time;
    unsigned int recv_time;
    unsigned int id;
    unsigned int type;
    unsigned int seq_no;
    unsigned int src_port;
    unsigned int dest_port;
    int roll;
    int pitch;
    int yaw;
    int ang_velocity;
};

// Global counters for loss calculation
unsigned int total_packets_received = 0;
unsigned int total_acks_lost = 0;
unsigned int total_packets_lost = 0;

// Modified transmit function with packet loss
void transmit_to_gsu(int sock, const char *filename) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Failed to open log file");
        return;
    }

    struct sockaddr_in gsu_addr = {
        .sin_family = AF_INET,
        .sin_port = htons(GSU_PORT),
        .sin_addr.s_addr = inet_addr("127.0.0.1")
    };

    char buffer[1024];
    while (fgets(buffer, sizeof(buffer), file)) {
        // Simulate 10% packet loss
        if ((rand() % 100) >= (PACKET_LOSS_RATE * 100)) {
            sendto(sock, buffer, strlen(buffer), 0,
                  (struct sockaddr*)&gsu_addr, sizeof(gsu_addr));
        } else {
            total_packets_lost++;
            printf("[SIM] Packet lost (GSU transmission)\n");
        }
    }
    fclose(file);
}

// New function for ACK loss ratio
float calculate_ack_loss_ratio() {
    if (total_packets_received == 0) return 0.0;
    return (float)total_acks_lost / total_packets_received * 100.0;
}

// Function to display the received packet
void display_packet(const struct packet *pkt) {
    // Display packet data by sensor type
    printf("\n--- GSU Display ---\n");
    printf("Gen Time: %u | Recv Time: %u\n", pkt->gen_time, pkt->recv_time);
    printf("Sensor: 0x%02X | Type: %u\n", pkt->id, pkt->type);
    printf("Roll: %d° | Pitch: %d° | Yaw: %d° | AngVel: %d°/s\n", 
            pkt->roll, pkt->pitch, pkt->yaw, pkt->ang_velocity);
    printf("------------------\n");
}

int main() {
    srand(time(NULL));
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        perror("Socket creation failed");
        return 1;
    }

    struct sockaddr_in server_addr = {
        .sin_family = AF_INET,
        .sin_port = htons(PORT),
        .sin_addr.s_addr = INADDR_ANY
    };

    if (bind(sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        return 1;
    }

    while (1) {
        fd_set readfds;
        struct timeval timeout = {1, 0};
        FD_ZERO(&readfds);
        FD_SET(sock, &readfds);

        if (select(sock+1, &readfds, NULL, NULL, &timeout) > 0) {
            struct packet pkt;
            int bytes = recvfrom(sock, &pkt, sizeof(pkt), 0, NULL, NULL);
            if (bytes > 0) {
                total_packets_received++;
                pkt.recv_time = time(NULL);

                // Display the received packet
                display_packet(&pkt);

                // Simulate ACK loss (10% loss)
                if ((rand() % 100) < (PACKET_LOSS_RATE * 100)) {
                    total_acks_lost++;
                    printf("[SIM] ACK lost for packet %d\n", pkt.seq_no);
                } else {
                    struct packet ack = {.type = 6, .seq_no = pkt.seq_no};
                    sendto(sock, &ack, sizeof(ack), 0, 
                           (struct sockaddr*)&server_addr, sizeof(server_addr));
                    printf("[SIM] ACK sent for packet %d\n", pkt.seq_no);
                }
            }
        }

        // Display loss ratio every 2 minutes
        static time_t last_display = 0;
        if (time(NULL) - last_display >= TRANSMIT_INTERVAL) {
            printf("\n[STATS] Packet-to-ACK loss ratio: %.2f%%\n",
                   calculate_ack_loss_ratio());
            printf("[STATS] Total packets lost: %u\n", total_packets_lost);
            last_display = time(NULL);
        }
    }

    // Cleanup
    close(sock);
    return 0;
}
