#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>

#define SERVERADDR "127.0.0.1"
#define SERVERPORT 5002
#define CLIENTPORT 12350  // Unique port for Cell Gauge
#define CELL_GAUGE_INTERVAL 10  // Send every 10 seconds (adjust per requirements)

struct packet {
    uint8_t id;           // Sensor ID (BQ41250)
    uint8_t seq_no;
    uint8_t type;         // 4 for Cell Gauge (as per requirements)
    uint8_t src_port;
    uint8_t dest_port;
    uint32_t gen_time;    // Packet generation time
    uint32_t recv_time;   // Filled by server
    uint8_t battery_pct;  // Battery percentage (0-100%)
    float cell_voltage;   // Individual cell voltage (V)
};

void generate_cell_gauge_data(uint8_t *battery_pct, float *cell_voltage) {
    // Simulate battery drain with occasional recharge
    static uint8_t last_pct = 100;
    
    if (last_pct <= 20) {  // Recharge cycle (per requirements)
        last_pct = 100;
    } else {
        last_pct -= rand() % 3;  // Random drain: 0-2% per interval
    }
    
    *battery_pct = last_pct;
    *cell_voltage = 3.6f + (rand() % 11) / 100.0f;  // Simulate cell voltage: 3.60V-3.70V
}

int main() {
    struct sockaddr_in s_server;
    int sock, bytes_received, si_len = sizeof(s_server), bytes_sent;
    
    // Create socket
    sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sock < 0) {
        perror("Socket creation failed");
        return 1;
    }

    // Configure server address
    s_server.sin_family = AF_INET;
    s_server.sin_port = htons(SERVERPORT);
    inet_aton(SERVERADDR, &s_server.sin_addr);

    // Bind client port
    struct sockaddr_in client_addr;
    client_addr.sin_family = AF_INET;
    client_addr.sin_addr.s_addr = INADDR_ANY;
    client_addr.sin_port = htons(CLIENTPORT);
    bind(sock, (struct sockaddr *)&client_addr, sizeof(client_addr));

    struct packet pkt;
    struct packet ack_pkt;
    uint8_t seq_counter = 0;
    srand(time(NULL));

    while(1) {
        // Generate battery data
        generate_cell_gauge_data(&pkt.battery_pct, &pkt.cell_voltage);
        
        // Fill packet
        pkt.id = 0x05;                  // BQ41250 ID (unique)
        pkt.seq_no = seq_counter++;
        pkt.type = 4;                   // Cell Gauge type (as per requirements)
        pkt.src_port = CLIENTPORT & 0xFF;
        pkt.dest_port = SERVERPORT & 0xFF;
        pkt.gen_time = time(NULL);
        
        int ack_received = 0;
        int attempts = 0;
        const int max_attempts = 3;

        while(!ack_received && attempts < max_attempts) {
            // Send packet
            bytes_sent = sendto(sock, &pkt, sizeof(pkt), 0, 
                               (struct sockaddr *)&s_server, si_len);
            
            printf("[CELL GAUGE] Sent packet %d - Battery: %d%%, Cell Voltage: %.2fV\n",
                   pkt.seq_no, pkt.battery_pct, pkt.cell_voltage);

            // Wait for ACK with timeout
            fd_set readfds;
            struct timeval timeout = {5, 0}; // 5 second timeout
            
            FD_ZERO(&readfds);
            FD_SET(sock, &readfds);
            
            int ready = select(sock+1, &readfds, NULL, NULL, &timeout);
            
            if(ready > 0) {
                bytes_received = recvfrom(sock, &ack_pkt, sizeof(ack_pkt), 0,
                                         (struct sockaddr *)&s_server, &si_len);
                
                if(bytes_received > 0 && 
                   ack_pkt.seq_no == pkt.seq_no && 
                   ack_pkt.type == 6) {  // Type 6 = ACK
                    printf("[CELL GAUGE] ACK received for packet %d\n", pkt.seq_no);
                    ack_received = 1;
                    
                    // Power mode change logic would be handled by the server
                }
            } else {
                printf("[CELL GAUGE] Timeout waiting for ACK, retrying...\n");
                attempts++;
            }
        }

        if(!ack_received) {
            printf("[CELL GAUGE] Max retries reached for packet %d, continuing...\n", pkt.seq_no);
        }

        sleep(CELL_GAUGE_INTERVAL);  // Wait for next transmission
    }

    close(sock);
    return 0;
}