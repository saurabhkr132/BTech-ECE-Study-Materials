#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>  // Added this for 'close' function

#define GSU_PORT 6002
#define MSP430_PORT 5002

// Packet structure matching MSP430's format
struct sensor_packet {
    uint32_t gen_time;
    uint32_t recv_time;
    uint8_t id;
    uint8_t type;
    uint8_t seq_no;
    uint8_t src_port;
    uint8_t dest_port;
    union {
        struct {  // ADCS (type 0)
            int16_t roll;
            int16_t pitch;
            int16_t yaw;
            int16_t ang_velocity;
        } adcs;
        int16_t temp;     // Temperature (type 1)
        float voltage;    // Voltage (type 2)
        float current;    // Current (type 3)
        struct {          // Cell Gauge (type 4)
            uint8_t battery_pct;
            float cell_voltage;
        } cell;
        struct {          // OBU (type 5)
            uint8_t system_status;
            uint16_t error_codes;
            float cpu_temp;
        } obu;
    } data;
};

const char* get_sensor_name(uint8_t type) {
    const char* names[] = {"ADCS", "Temperature", "Voltage", "Current", 
                          "Cell Gauge", "OBU", "ACK"};
    return (type < 7) ? names[type] : "Unknown";
}

void display_packet(const struct sensor_packet *pkt) {
    printf("\n=== GSU Display ===\n");
    printf("Sensor: %s (ID: 0x%02X)\n", get_sensor_name(pkt->type), pkt->id);
    printf("Seq: %-4d | Src Port: %-5d | Dest Port: %-5d\n", 
           pkt->seq_no, pkt->src_port, pkt->dest_port);
    printf("Gen Time: %-20s", ctime((time_t*)&pkt->gen_time));  // Cast gen_time to time_t
    printf("Recv Time: %-20s", ctime((time_t*)&pkt->recv_time));  // Cast recv_time to time_t

    switch(pkt->type) {
        case 0: // ADCS
            printf("Attitude: Roll=%-4d Pitch=%-4d Yaw=%-4d AngVel=%-4d°/s\n",
                   pkt->data.adcs.roll, pkt->data.adcs.pitch,
                   pkt->data.adcs.yaw, pkt->data.adcs.ang_velocity);
            break;
        case 1: // Temperature
            printf("Temperature: %d°C\n", pkt->data.temp);
            break;
        case 2: // Voltage
            printf("Bus Voltage: %.2fV\n", pkt->data.voltage);
            break;
        case 3: // Current
            printf("Current Draw: %.1fmA\n", pkt->data.current);
            break;
        case 4: // Cell Gauge
            printf("Battery: %d%% | Cell Voltage: %.2fV\n",
                   pkt->data.cell.battery_pct, pkt->data.cell.cell_voltage);
            break;
        case 5: // OBU
            printf("System Status: 0x%02X | Errors: 0x%04X\n",
                   pkt->data.obu.system_status, pkt->data.obu.error_codes);
            printf("CPU Temp: %.1f°C\n", pkt->data.obu.cpu_temp);
            break;
    }
    printf("===================\n");
}

void send_ack(int sock, uint8_t seq_no) {
    struct sockaddr_in msp430_addr = {
        .sin_family = AF_INET,
        .sin_port = htons(MSP430_PORT),
        .sin_addr.s_addr = inet_addr("127.0.0.1")
    };
    
    // Simple ACK packet (just sequence number)
    sendto(sock, &seq_no, sizeof(seq_no), 0,
          (struct sockaddr*)&msp430_addr, sizeof(msp430_addr));
}

int main() {
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        perror("Socket creation failed");
        return 1;
    }

    struct sockaddr_in gsu_addr = {
        .sin_family = AF_INET,
        .sin_addr.s_addr = htonl(INADDR_ANY),
        .sin_port = htons(GSU_PORT)
    };

    if (bind(sock, (struct sockaddr*)&gsu_addr, sizeof(gsu_addr)) < 0) {
        perror("Bind failed");
        close(sock);
        return 1;
    }

    printf("Ground Station Unit (GSU) [Phase 4] listening on port %d\n", GSU_PORT);
    printf("Press Ctrl+C to exit\n\n");

    struct sensor_packet pkt;
    unsigned int total_packets = 0;
    unsigned int lost_packets = 0;
    time_t last_stat_time = time(NULL);

    while (1) {
        struct sockaddr_in sender_addr;
        socklen_t len = sizeof(sender_addr);
        
        int bytes = recvfrom(sock, &pkt, sizeof(pkt), 0,
                           (struct sockaddr*)&sender_addr, &len);
        
        if (bytes > 0) {
            total_packets++;
            
            // Display received packet
            display_packet(&pkt);
            
            // Send ACK back to MSP430 (may be lost in Phase 4 simulation)
            send_ack(sock, pkt.seq_no);
            
            // Periodically display statistics
            if (time(NULL) - last_stat_time >= 10) { // Every 10 seconds
                float loss_percent = (lost_packets * 100.0) / total_packets;
                printf("\n[STATS] Packets: %u | Lost: %u (%.1f%%)\n",
                       total_packets, lost_packets, loss_percent);
                last_stat_time = time(NULL);
            }
        } else {
            lost_packets++; // Count receive failures
        }
    }
    close(sock);
    return 0;
}