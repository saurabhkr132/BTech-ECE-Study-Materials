#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/select.h>  // Required for fd_set
#include <sys/time.h>    // Required for struct timeval

#define PORT 5001
#define GSU_PORT 6000
#define LOG_FILE "sensor_log.txt"
#define TRANSMIT_INTERVAL 120 // 2 minutes

struct packet {
    uint8_t id;
    uint8_t seq_no;
    uint8_t type;
    uint8_t src_port;
    uint8_t dest_port;
    uint32_t gen_time;
    uint32_t recv_time;
    union {
        struct {
            int16_t roll, pitch, yaw, ang_velocity;
        } adcs;
        int16_t temp;
        float voltage;
        float current;
        struct {
            uint8_t battery_pct;
            float cell_voltage;
        } cell;
        struct {
            uint8_t system_status;
            uint16_t error_codes;
            float cpu_temp;
        } obu;
    } data;
};

const char* get_sensor_name(uint8_t type) {
    const char* names[] = {"ADCS", "Temperature", "Voltage", "Current", 
                          "Cell Gauge", "OBU", "ACK"};
    return names[type];
}

void log_to_file(FILE *file, struct packet *pkt) {
    fprintf(file, "%u,%u,0x%02X,%d,%d,%d,%d", 
            pkt->gen_time, pkt->recv_time, pkt->id, 
            pkt->type, pkt->seq_no, pkt->src_port, 
            pkt->dest_port);
    // fprintf(file, "%u,%u,0x%02X,%u,%u,%u,%u",
    //     pkt->gen_time, pkt->recv_time, pkt->id, 
    //         pkt->type, pkt->seq_no, pkt->src_port, 
    //         pkt->dest_port);
        

    switch(pkt->type) {
        case 0:
            fprintf(file, "%d,%d,%d,%d\n", pkt->data.adcs.roll, 
                    pkt->data.adcs.pitch, pkt->data.adcs.yaw, 
                    pkt->data.adcs.ang_velocity);
            break;
        case 1:
            fprintf(file, "%d\n", pkt->data.temp);
            break;
        case 2:
            fprintf(file, "%.2f\n", pkt->data.voltage);
            break;
        case 3:
            fprintf(file, "%.1f\n", pkt->data.current);
            break;
        case 4:
            fprintf(file, "%d,%.2f\n", pkt->data.cell.battery_pct, 
                    pkt->data.cell.cell_voltage);
            break;
        case 5:
            fprintf(file, "0x%02X,0x%04X,%.1f\n", 
                    pkt->data.obu.system_status, 
                    pkt->data.obu.error_codes, 
                    pkt->data.obu.cpu_temp);
            break;
    }
}

void transmit_to_gsu(int sock, const char *filename) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Failed to open log file");
        return;
    }

    struct sockaddr_in gsu_addr = {
        .sin_family = AF_INET,
        .sin_port = htons(GSU_PORT),
        .sin_addr.s_addr = inet_addr("127.0.0.1")
    };

    char buffer[1024];
    while (fgets(buffer, sizeof(buffer), file)) {
        sendto(sock, buffer, strlen(buffer), 0,
              (struct sockaddr*)&gsu_addr, sizeof(gsu_addr));
    }

    fclose(file);
    truncate(LOG_FILE, 0);
}

int main() {
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        perror("Socket creation failed");
        return 1;
    }

    struct sockaddr_in server_addr = {
        .sin_family = AF_INET,
        .sin_addr.s_addr = htonl(INADDR_ANY),
        .sin_port = htons(PORT)
    };

    if (bind(sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        close(sock);
        return 1;
    }

    FILE *log_file = fopen(LOG_FILE, "a");
    if (!log_file) perror("Failed to open log file");

    time_t last_transmit = time(NULL);
    printf("MSP430 Server (Phase 2) running...\n");

    while (1) {
        if (difftime(time(NULL), last_transmit) >= TRANSMIT_INTERVAL) {
            transmit_to_gsu(sock, LOG_FILE);
            last_transmit = time(NULL);
        }

        struct packet pkt;
        struct sockaddr_in client_addr;
        socklen_t len = sizeof(client_addr);

        fd_set readfds;
        struct timeval timeout = {1, 0};
        FD_ZERO(&readfds);
        FD_SET(sock, &readfds);

        if (select(sock+1, &readfds, NULL, NULL, &timeout) > 0) {
            int bytes = recvfrom(sock, &pkt, sizeof(pkt), 0,
                           (struct sockaddr*)&client_addr, &len);
            if (bytes > 0) {
                pkt.recv_time = time(NULL);
                if (log_file) {
                    log_to_file(log_file, &pkt);
                    fflush(log_file);  // Ensure data is written immediately
                }
                printf("Received %s packet (Seq: %d)\n", 
                       get_sensor_name(pkt.type), pkt.seq_no);

                struct packet ack = {.type = 6, .seq_no = pkt.seq_no};
                sendto(sock, &ack, sizeof(ack), 0,
                      (struct sockaddr*)&client_addr, len);
            }
        }
    }
    close(sock);
    if (log_file) fclose(log_file);
    return 0;
}