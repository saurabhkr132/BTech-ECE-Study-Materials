#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>

#define GSU_PORT 6000

void display_packet(const char *data) {
    char buffer[1024];
    strncpy(buffer, data, sizeof(buffer));
    buffer[sizeof(buffer) - 1] = '\0';  // Ensure null-termination

    char *token = strtok(buffer, ",");
    printf("\n--- GSU Display ---\n");
    printf("Gen Time: %s | Recv Time: %s\n", token, strtok(NULL, ","));
    printf("Sensor: 0x%s | Type: %s\n", strtok(NULL, ","), strtok(NULL, ","));
    
    // Print remaining fields based on type
    while ((token = strtok(NULL, ","))) {
        printf("%s ", token);
    }
    printf("\n------------------\n");
}


int main() {
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in gsu_addr = {
        .sin_family = AF_INET,
        .sin_addr.s_addr = htonl(INADDR_ANY),
        .sin_port = htons(GSU_PORT)
    };
    bind(sock, (struct sockaddr*)&gsu_addr, sizeof(gsu_addr));

    printf("Ground Station Unit (GSU) listening on port %d\n", GSU_PORT);
    char buffer[1024];

    while (1) {
        struct sockaddr_in sender_addr;
        socklen_t len = sizeof(sender_addr);
        int bytes = recvfrom(sock, buffer, sizeof(buffer), 0,
                           (struct sockaddr*)&sender_addr, &len);
        if (bytes > 0) {
            buffer[bytes] = '\0';
            display_packet(buffer);
        }
    }
    return 0;
}