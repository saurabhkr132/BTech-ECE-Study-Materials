#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>

#define SERVERADDR "127.0.0.1"
#define SERVERPORT 5001
#define CLIENTPORT 12349  // Unique port for Current Sensor
#define CURRENT_INTERVAL 3  // Send every 3 seconds (as per requirements)

struct packet {
    uint8_t id;           // Sensor ID (LTC6102)
    uint8_t seq_no;
    uint8_t type;         // 3 for Current (as per requirements)
    uint8_t src_port;
    uint8_t dest_port;
    uint32_t gen_time;    // Packet generation time
    uint32_t recv_time;   // Filled by server
    float current;        // Current in mA (using float for precision)
};

void generate_current_data(float *current) {
    // Simulate spacecraft current draw: 0mA to 5000mA (5A) with spikes
    *current = (rand() % 5001) / 1.0f;  // Range: 0.0mA to 5000.0mA
    // Simulate occasional current spikes (20% chance)
    if (rand() % 5 == 0) *current += (rand() % 2001); // Add 0-2000mA spike
}

int main() {
    struct sockaddr_in s_server;
    int sock, bytes_received, si_len = sizeof(s_server), bytes_sent;
    
    // Create socket
    sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sock < 0) {
        perror("Socket creation failed");
        return 1;
    }

    // Configure server address
    s_server.sin_family = AF_INET;
    s_server.sin_port = htons(SERVERPORT);
    inet_aton(SERVERADDR, &s_server.sin_addr);

    // Bind client port
    struct sockaddr_in client_addr;
    client_addr.sin_family = AF_INET;
    client_addr.sin_addr.s_addr = INADDR_ANY;
    client_addr.sin_port = htons(CLIENTPORT);
    bind(sock, (struct sockaddr *)&client_addr, sizeof(client_addr));

    struct packet pkt;
    struct packet ack_pkt;
    uint8_t seq_counter = 0;
    srand(time(NULL));

    while(1) {
        // Generate current data
        generate_current_data(&pkt.current);
        
        // Fill packet
        pkt.id = 0x04;                  // LTC6102 ID (unique)
        pkt.seq_no = seq_counter++;
        pkt.type = 3;                   // Current type (as per requirements)
        pkt.src_port = CLIENTPORT & 0xFF;
        pkt.dest_port = SERVERPORT & 0xFF;
        pkt.gen_time = time(NULL);
        
        int ack_received = 0;
        int attempts = 0;
        const int max_attempts = 3;

        while(!ack_received && attempts < max_attempts) {
            // Send packet
            bytes_sent = sendto(sock, &pkt, sizeof(pkt), 0, 
                               (struct sockaddr *)&s_server, si_len);
            
            printf("[CURRENT] Sent packet %d - Current: %.1fmA\n",
                   pkt.seq_no, pkt.current);

            // Wait for ACK with timeout
            fd_set readfds;
            struct timeval timeout = {5, 0}; // 5 second timeout
            
            FD_ZERO(&readfds);
            FD_SET(sock, &readfds);
            
            int ready = select(sock+1, &readfds, NULL, NULL, &timeout);
            
            if(ready > 0) {
                bytes_received = recvfrom(sock, &ack_pkt, sizeof(ack_pkt), 0,
                                         (struct sockaddr *)&s_server, &si_len);
                
                if(bytes_received > 0 && 
                   ack_pkt.seq_no == pkt.seq_no && 
                   ack_pkt.type == 6) {  // Type 6 = ACK
                    printf("[CURRENT] ACK received for packet %d\n", pkt.seq_no);
                    ack_received = 1;
                }
            } else {
                printf("[CURRENT] Timeout waiting for ACK, retrying...\n");
                attempts++;
            }
        }

        if(!ack_received) {
            printf("[CURRENT] Max retries reached for packet %d, continuing...\n", pkt.seq_no);
        }

        sleep(CURRENT_INTERVAL);  // Wait for next transmission (3 seconds)
    }

    close(sock);
    return 0;
}