#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>

#define SERVERADDR "127.0.0.1"
#define SERVERPORT 5000
#define CLIENTPORT 12347  // Unique port for Temperature Sensor
#define TEMP_INTERVAL 5   // Send every 5 seconds (as per requirements)

struct packet {
    uint8_t id;           // Sensor ID (TMP461-SP)
    uint8_t seq_no;
    uint8_t type;         // 1 for Temperature (as per requirements)
    uint8_t src_port;
    uint8_t dest_port;
    uint32_t gen_time;    // Packet generation time
    uint32_t recv_time;   // Filled by server
    int16_t temp;         // Temperature data (°C)
};

void generate_temp_data(int16_t *temp) {
    // Simulate realistic payload temperature: -40°C to +85°C (typical range for spacecraft)
    *temp = (rand() % 126) - 40;  // Range: -40 to +85°C
}

int main() {
    struct sockaddr_in s_server;
    int sock, bytes_received, si_len = sizeof(s_server), bytes_sent;
    
    // Create socket
    sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sock < 0) {
        perror("Socket creation failed");
        return 1;
    }

    // Configure server address
    s_server.sin_family = AF_INET;
    s_server.sin_port = htons(SERVERPORT);
    inet_aton(SERVERADDR, &s_server.sin_addr);

    // Bind client port
    struct sockaddr_in client_addr;
    client_addr.sin_family = AF_INET;
    client_addr.sin_addr.s_addr = INADDR_ANY;
    client_addr.sin_port = htons(CLIENTPORT);
    bind(sock, (struct sockaddr *)&client_addr, sizeof(client_addr));

    struct packet pkt;
    struct packet ack_pkt;
    uint8_t seq_counter = 0;
    srand(time(NULL));

    while(1) {
        // Generate temperature data
        generate_temp_data(&pkt.temp);
        
        // Fill packet
        pkt.id = 0x02;                  // TMP461-SP ID (arbitrary unique value)
        pkt.seq_no = seq_counter++;
        pkt.type = 1;                   // Temperature type (as per requirements)
        pkt.src_port = CLIENTPORT & 0xFF;
        pkt.dest_port = SERVERPORT & 0xFF;
        pkt.gen_time = time(NULL);
        
        int ack_received = 0;
        int attempts = 0;
        const int max_attempts = 3;

        while(!ack_received && attempts < max_attempts) {
            // Send packet
            bytes_sent = sendto(sock, &pkt, sizeof(pkt), 0, 
                               (struct sockaddr *)&s_server, si_len);
            
            printf("[TEMP] Sent packet %d - Temp: %d°C\n",
                   pkt.seq_no, pkt.temp);

            // Wait for ACK with timeout
            fd_set readfds;
            struct timeval timeout = {5, 0}; // 5 second timeout
            
            FD_ZERO(&readfds);
            FD_SET(sock, &readfds);
            
            int ready = select(sock+1, &readfds, NULL, NULL, &timeout);
            
            if(ready > 0) {
                bytes_received = recvfrom(sock, &ack_pkt, sizeof(ack_pkt), 0,
                                         (struct sockaddr *)&s_server, &si_len);
                
                if(bytes_received > 0 && 
                   ack_pkt.seq_no == pkt.seq_no && 
                   ack_pkt.type == 6) {  // Type 6 = ACK
                    printf("[TEMP] ACK received for packet %d\n", pkt.seq_no);
                    ack_received = 1;
                }
            } else {
                printf("[TEMP] Timeout waiting for ACK, retrying...\n");
                attempts++;
            }
        }

        if(!ack_received) {
            printf("[TEMP] Max retries reached for packet %d, continuing...\n", pkt.seq_no);
        }

        sleep(TEMP_INTERVAL);  // Wait for next transmission (5 seconds)
    }

    close(sock);
    return 0;
}