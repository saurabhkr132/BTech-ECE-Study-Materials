#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define PORT 5000

struct packet {
    uint8_t id;           // Sensor ID
    uint8_t seq_no;
    uint8_t type;         // Packet type (0-6)
    uint8_t src_port;
    uint8_t dest_port;
    uint32_t gen_time;    // Packet generation time
    uint32_t recv_time;   // Packet reception time (to be filled by server)
    union {
        struct {          // ADCS (type 0)
            int16_t roll, pitch, yaw, ang_velocity;
        } adcs;
        int16_t temp;     // Temperature (type 1)
        float voltage;    // Voltage (type 2)
        float current;    // Current (type 3)
        struct {          // Cell Gauge (type 4)
            uint8_t battery_pct;
            float cell_voltage;
        } cell;
        struct {          // OBU (type 5)
            uint8_t system_status;
            uint16_t error_codes;
            float cpu_temp;
        } obu;
    } data;
};

const char* get_sensor_name(uint8_t type) {
    const char* names[] = {"ADCS", "Temperature", "Voltage", "Current", 
                          "Cell Gauge", "OBU", "ACK"};
    return names[type];
}

void log_packet(struct packet *pkt) {
    printf("\n--- Received Packet ---\n");
    printf("Sensor: %s (ID: 0x%02X)\n", get_sensor_name(pkt->type), pkt->id);
    printf("Seq: %d | Src Port: %d | Dest Port: %d\n", 
           pkt->seq_no, pkt->src_port, pkt->dest_port);
    printf("Gen Time: %u | Recv Time: %u\n", pkt->gen_time, pkt->recv_time);
    
    switch(pkt->type) {
        case 0: // ADCS
            printf("Roll: %d° | Pitch: %d° | Yaw: %d° | AngVel: %d°/s\n",
                   pkt->data.adcs.roll, pkt->data.adcs.pitch,
                   pkt->data.adcs.yaw, pkt->data.adcs.ang_velocity);
            break;
        case 1: // Temperature
            printf("Temp: %d°C\n", pkt->data.temp);
            break;
        case 2: // Voltage
            printf("Bus Voltage: %.2fV\n", pkt->data.voltage);
            break;
        case 3: // Current
            printf("Current: %.1fmA\n", pkt->data.current);
            break;
        case 4: // Cell Gauge
            printf("Battery: %d%% | Cell Voltage: %.2fV\n",
                   pkt->data.cell.battery_pct, pkt->data.cell.cell_voltage);
            break;
        case 5: // OBU
            printf("Status: 0x%02X | Errors: 0x%04X | CPU Temp: %.1f°C\n",
                   pkt->data.obu.system_status, pkt->data.obu.error_codes,
                   pkt->data.obu.cpu_temp);
            break;
    }
    printf("----------------------\n");
}

int main() {
    int sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sock < 0) {
        perror("Socket creation failed");
        return 1;
    }

    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    server_addr.sin_port = htons(PORT);

    if (bind(sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        close(sock);
        return 1;
    }

    printf("MSP430 Server running on port %d\n", PORT);

    while(1) {
        struct packet pkt;
        struct sockaddr_in client_addr;
        socklen_t len = sizeof(client_addr);

        // Receive packet
        int bytes = recvfrom(sock, &pkt, sizeof(pkt), 0,
                           (struct sockaddr*)&client_addr, &len);
        
        if(bytes > 0) {
            // Record reception time
            pkt.recv_time = time(NULL);
            
            // Log packet (Phase 1 requirement)
            log_packet(&pkt);

            // Send ACK (type 6)
            struct packet ack = {
                .type = 6,       // ACK type
                .seq_no = pkt.seq_no,
                .id = pkt.id,    // Echo sensor ID
                .recv_time = pkt.recv_time
            };
            
            sendto(sock, &ack, sizeof(ack), 0,
                  (struct sockaddr*)&client_addr, len);
        }
    }
    close(sock);
    return 0;
}