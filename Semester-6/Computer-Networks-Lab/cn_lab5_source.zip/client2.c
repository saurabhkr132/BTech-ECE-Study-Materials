#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>

#define BUFFERSIZE 1024
#define SERVERADDR "127.0.0.1"
#define PORT 5000
#define NUM_MESSAGES 10

int main() {
    struct sockaddr_in s_server;
    int sock, bytes_received, si_len = sizeof(s_server), bytes_sent;
    char messages[NUM_MESSAGES][BUFFERSIZE];  // To store user input messages
    char send_buf[BUFFERSIZE], recv_buf[BUFFERSIZE];
    struct timeval send_times[NUM_MESSAGES], recv_times[NUM_MESSAGES];
    long total_rtt = 0;

    // Creating the client socket
    sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sock < 0) {
        printf("Socket creation failed.\n");
        return 1;
    }
    printf("Socket creation successful at %d\n", sock);

    // Assigning server IP and port
    s_server.sin_family = AF_INET;
    s_server.sin_port = htons(PORT);
    if (!inet_aton(SERVERADDR, &s_server.sin_addr)) {
        printf("IP network format conversion failed.\n");
        return 1;
    }
    printf("IP network format conversion successful.\n");

    // Prompts for messages to send
    for (int i = 0; i < NUM_MESSAGES; i++) {
        printf("Enter message %d: ", i + 1);
        fgets(messages[i], BUFFERSIZE - 10, stdin); 
        messages[i][strcspn(messages[i], "\n")] = 0;
    }

    // Send the messages to server
    for (int i = 0; i < NUM_MESSAGES; i++) {
        snprintf(send_buf, BUFFERSIZE, "%02d:ClientX:%.1000s", i, messages[i]);  // Add header
        gettimeofday(&send_times[i], NULL);  // Timestamp before sending

        bytes_sent = sendto(sock, send_buf, strlen(send_buf) + 1, 0, (struct sockaddr*)&s_server, si_len);
        if (bytes_sent < 0) {
            printf("Error sending data\n");
            return 1;
        }
        printf("Sent (%d): %s\n", i, send_buf);
    }

    // Receive responses and compute RTT
    for (int i = 0; i < NUM_MESSAGES; i++) {
        bytes_received = recvfrom(sock, recv_buf, sizeof(recv_buf), 0, (struct sockaddr*)&s_server, &si_len);
        if (bytes_received < 0) {
            printf("Error receiving data\n");
            return 1;
        }
        gettimeofday(&recv_times[i], NULL);  // Timestamp after receiving

        // Extract sequence number
        int seq;
        sscanf(recv_buf, "%02d:", &seq);
        printf("Received (%d): %s\n", seq, recv_buf);

        // Calculate RTT
        long rtt_sec = recv_times[i].tv_sec - send_times[seq].tv_sec;
        long rtt_usec = recv_times[i].tv_usec - send_times[seq].tv_usec;
        if (rtt_usec < 0) {
            rtt_sec--;
            rtt_usec += 1000000;
        }
        long rtt = rtt_sec * 1000000 + rtt_usec;
        total_rtt += rtt;

        printf("RTT for message %d: %ld microseconds\n", seq, rtt);
    }

    printf("Average RTT: %ld microseconds\n", total_rtt / NUM_MESSAGES);

    return 0;
}