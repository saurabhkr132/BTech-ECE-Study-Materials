#include<sys/socket.h>
#include<arpa/inet.h>
#include<stdio.h>
#include<string.h>

#define BUFFERSIZE 1024
#define SERVERADDR "127.0.0.1"

int main()
{
  struct sockaddr_in s_server;
  int sock, bytes_received, si_len = sizeof(s_server), bytes_sent;
  char recv_buf[BUFFERSIZE], send_buf[BUFFERSIZE];

  // Creating the client socket
  sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
  if(sock < 0)
    {
      printf("Socket creation failed.\n");
      return 1;
    }
  else
    {
      printf("Socket creation successful at %d\n", sock);
    }


  // Assigning server IP and port for sending
  s_server.sin_family = AF_INET;
  s_server.sin_port = htons(5000);

  if(!inet_aton(SERVERADDR, &s_server.sin_addr))
    {
      printf("IP network format conversion failed.\n");
      return 1;
    }
  else
    {
      printf("IP network format conversion successful.\n");
    }

  
  printf("Message to send: ");
  fgets(send_buf, BUFFERSIZE, stdin);

  // Sending the message to the server
  bytes_sent = sendto(sock, send_buf, sizeof(send_buf), 0, \
		      (struct sockaddr*)&s_server, si_len);
  printf("%d bytes sent: %s\n", bytes_sent, send_buf);

  // Wait for the echo message
  bytes_received = recvfrom(sock, recv_buf, sizeof(recv_buf), \
		      0, (struct sockaddr*)&s_server, &si_len);
  printf("%d bytes received: %s\n", bytes_received, recv_buf);

  return 0;
}
