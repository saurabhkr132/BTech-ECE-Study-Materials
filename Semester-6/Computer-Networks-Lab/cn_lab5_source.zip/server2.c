#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h>
#include <stdio.h>
#include <sys/time.h>

#define BUFFERSIZE 1024
#define PORT 5000
#define NUM_MESSAGES 10

int main() {
    int sock;
    int bind_status, bytes_received, bytes_sent;
    char send_buf[BUFFERSIZE], recv_buf[BUFFERSIZE];
    struct sockaddr_in s_server, s_client;
    int si_len = sizeof(s_client);
    struct timeval recv_time, send_time;
    int received_seq[NUM_MESSAGES] = {0};  // Track received sequence numbers

    // Creating the socket
    sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sock < 0) {
        printf("Socket creation failed.\n");
        return 1;
    }
    printf("Socket created with descriptor %d\n", sock);

    // Initialising and binding the socket
    s_server.sin_family = AF_INET;
    s_server.sin_port = htons(PORT);
    s_server.sin_addr.s_addr = htonl(INADDR_ANY);

    bind_status = bind(sock, (struct sockaddr*)&s_server, sizeof(s_server));
    if (bind_status < 0) {
        printf("Binding socket failed.\n");
        return 1;
    }
    printf("Binding socket successful.\n");

    // Receive all messages
    for (int i = 0; i < NUM_MESSAGES; i++) {
        bytes_received = recvfrom(sock, recv_buf, sizeof(recv_buf), 0, (struct sockaddr*)&s_client, &si_len);
        if (bytes_received < 0) {
            printf("Error receiving data\n");
            return 1;
        }

        // Get the current timestamp when data is received
        gettimeofday(&recv_time, NULL);

        // Extract sequence number
        int seq;
        sscanf(recv_buf, "%02d:", &seq);
        received_seq[seq] = 1;  // Mark sequence as received

        printf("Received from %s:%d | Seq: %d | Data: %s\n",
               inet_ntoa(s_client.sin_addr), ntohs(s_client.sin_port), seq, recv_buf);

        // Echo the message back
        sprintf(send_buf, "%02d:%s", seq, recv_buf + 3);
        bytes_sent = sendto(sock, send_buf, sizeof(send_buf), 0, (struct sockaddr*)&s_client, si_len);
        if (bytes_sent < 0) {
            printf("Error sending data\n");
            return 1;
        }

        gettimeofday(&send_time, NULL);

        printf("Echoed Seq %d back to client\n", seq);
    }

    // Check if all messages were received in order
    printf("\nOrder Check: ");
    int in_order = 1;
    for (int i = 0; i < NUM_MESSAGES; i++) {
        if (received_seq[i] == 0) {
            printf("MISSING %d ", i);
            in_order = 0;
        }
    }
    printf("\n");

    if (in_order)
        printf("All messages received in order!\n");
    else
        printf("Some messages were lost or out of order!\n");

    return 0;
}