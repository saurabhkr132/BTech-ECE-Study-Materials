#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>

#define SERVERADDR "127.0.0.1"
#define SERVERPORT 5000
#define CLIENTPORT 12345
#define N 10 // Number of packets to send

struct packet
{
    uint8_t seq_no;
    uint8_t type;
    uint8_t src_port;
    uint8_t dest_port;
    char data[20];
};

int main()
{
    struct sockaddr_in s_server;
    int sock, bytes_received, si_len = sizeof(s_server), bytes_sent;

    struct timeval start, end;

    // Creating the client socket
    sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sock < 0)
    {
        printf("Socket creation failed.\n");
        return 1;
    }
    else
    {
        printf("Socket creation successful at %d\n", sock);
    }

    // Assigning server IP and port for sending
    s_server.sin_family = AF_INET;
    s_server.sin_port = htons(SERVERPORT);

    if (!inet_aton(SERVERADDR, &s_server.sin_addr))
    {
        printf("IP network format conversion failed.\n");
        return 1;
    }
    else
    {
        printf("IP network format conversion successful.\n");
    }

    struct packet pkt;
    struct packet server_pkt;
    char input_buf[100];

    struct sockaddr_in client_addr;
    client_addr.sin_family = AF_INET;
    client_addr.sin_addr.s_addr = INADDR_ANY;
    client_addr.sin_port = htons(CLIENTPORT);

    bind(sock, (struct sockaddr *)&client_addr, sizeof(client_addr));

    for (int i = 0; i < N; i++)
    {
        printf("Enter message %d: ", i + 1);
        fgets(input_buf, sizeof(input_buf), stdin);
        input_buf[strcspn(input_buf, "\n")] = '\0';

        pkt.seq_no = i;
        pkt.type = 0;
        pkt.src_port = CLIENTPORT & 0xFF;
        pkt.dest_port = SERVERPORT & 0xFF;
        strncpy(pkt.data, input_buf, sizeof(pkt.data));

        int ack_received = 0;

        while (!ack_received) {
            bytes_sent = sendto(sock, &pkt, sizeof(pkt), 0, (struct sockaddr *)&s_server, si_len);
            printf("Sent packet %d: %s\n", pkt.seq_no, pkt.data);
        
            // Set timeout
            fd_set readfds;
            struct timeval timeout;
        
            FD_ZERO(&readfds);
            FD_SET(sock, &readfds);
            timeout.tv_sec = 5;
        
            int ready = select(sock + 1, &readfds, NULL, NULL, &timeout);
        
            if (ready == -1) {
                perror("select error");
                continue;
            } else if (ready == 0) { // timeout
                printf("Timeout! Retrying packet %d...\n", pkt.seq_no);
            } else {
                bytes_received = recvfrom(sock, &server_pkt, sizeof(server_pkt), 0, (struct sockaddr *)&s_server, &si_len);
                if (bytes_received > 0 && server_pkt.seq_no == pkt.seq_no && server_pkt.type == 1) {
                    printf("ACK received for packet %d\n", pkt.seq_no);
                    ack_received = 1;
                } else {
                    printf("Incorrect ACK or packet corrupted. Retrying...\n");
                }
            }
        }
        
        printf("Received packet:\n");
        printf("Seq No: %d, Type: %d, Src Port: %d, Dest Port: %d, Data: %s\n",
            server_pkt.seq_no, server_pkt.type, server_pkt.src_port, server_pkt.dest_port, server_pkt.data);
        printf("-------------------------\n");
    }

    return 0;
}