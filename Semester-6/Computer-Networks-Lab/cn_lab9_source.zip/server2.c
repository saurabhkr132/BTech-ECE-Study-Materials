#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h>
#include <stdio.h>

#define PORT 5000

struct packet
{
    uint8_t seq_no;
    uint8_t type;
    uint8_t src_port;
    uint8_t dest_port;
    char data[20];
};

int main()
{
    int sock, recv_calls = 0;
    int bind_status, bytes_received, bytes_sent;

    struct sockaddr_in s_server, s_client;
    int si_len = sizeof(s_client);

    // Creating the socket
    sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sock < 0)
    {
        printf("Socket creation failed.\n");
    }
    else
    {
        printf("Socket created with descriptor %d\n", sock);
    }

    // Initializing and binding the socket
    s_server.sin_family = AF_INET;
    s_server.sin_port = htons(PORT);
    s_server.sin_addr.s_addr = htonl(INADDR_ANY);

    bind_status = bind(sock, (struct sockaddr *)&s_server, sizeof(s_server));
    if (bind_status < 0)
    {
        printf("Binding socket failed.\n");
    }
    else
    {
        printf("Binding socket successful.\n");
    }

    struct packet server_pkt;
    struct packet pkt;
    
    while ((bytes_received = recvfrom(sock, &pkt, sizeof(pkt), 0, (struct sockaddr *)&s_client, &si_len)) > 0)
    {
        printf("Received packet:\n");
        printf("Seq No: %d, Type: %d, Src Port: %d, Dest Port: %d, Data: %s\n", pkt.seq_no, pkt.type, pkt.src_port, pkt.dest_port, pkt.data);
        memcpy(&server_pkt, &pkt, sizeof(pkt));
        server_pkt.type = 1;
        server_pkt.dest_port = pkt.src_port;
        server_pkt.src_port = pkt.dest_port;
        sendto(sock, &server_pkt, sizeof(server_pkt), 0, (struct sockaddr *)&s_client, si_len);
    }

    return 0;
}
