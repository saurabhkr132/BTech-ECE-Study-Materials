int BST::findMinElement     ()
{
	bNode* traverseNode = treeRoot;
	bNode* minNode=NULL;

	if (treeRoot == NULL) return -1;

	while (traverseNode != NULL)
	{
		minNode = traverseNode;
		traverseNode = traverseNode->left; //right -> left
	}
	
	return minNode->bNodeVal ;
}

int BST::findMaxElement     ()
{
	bNode* traverseNode = treeRoot;
	bNode* maxNode=NULL; //minNode -> maxNode, although, it doesn't make difference

	if (treeRoot == NULL) return -1;

  //A while loop was missing from here
  while (traverseNode != NULL)
	{
		maxNode = traverseNode;
		traverseNode = traverseNode->right;
	}
	
	return maxNode->bNodeVal ; //treeRoot -> maxNode
}