#include<iostream>
#include<set>
using namespace std;

int main()
{
  set<int> mySet; //set
  int num; //temporary variable

  //Reading 10 integers from the user
  cout<<"Enter 10 integers: ";
  for(int i=0; i<10; ++i)
  {
    cin>>num;
    mySet.insert(num); //Inserting integers into the set
  }

  //Printing the size of the set
  cout<<"The size of the set is "<<mySet.size()<<endl;

  //Reading 5 integers from the user
  cout<<"Enter 5 integers to search in the set: ";
  for(int i=0; i<5; ++i)
  {
    cin>>num;
    //If the count of the given number > 0, the number is present in the set
    if(mySet.count(num)>0) 
      cout<<"Element found\n";
    else
      cout<<"Element not found\n";
  }
  
  return 0;
}