#include<iostream>
#include<map>
using namespace std;

int main()
{
  map<int, string> myMap;
  int id;

  //Storing the map
  myMap[1] = "Divya";
  myMap[2] = "Yohan";
  myMap[3] = "Rachel";
  myMap[4] = "John";

  //Reading input from the user
  cout<<"Enter an ID: ";
  cin>>id;

  //Searching for the key in the map
  map<int, string>::iterator i = myMap.begin(); //getting an iterator pointing to the first elemnt in the map
  bool idFoundFlag = false;

  while(i != myMap.end())
  {
    //If the entered ID matches with the ID in the map, print the student name
    //else keep increment the iterator till the end of the map
    if(id == i->first){
      cout<<"The ID belongs to "<<i->second<<endl;
      idFoundFlag = true;
      break;
    }
    else
      ++i; //increment the iterator
  }

  if(!idFoundFlag)
    cout<<"Student ID not found\n";

  return 0;
}